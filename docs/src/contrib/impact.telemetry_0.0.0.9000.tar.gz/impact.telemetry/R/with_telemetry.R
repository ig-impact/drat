#' @importFrom cli cli_warn
#' @importFrom logger log_info log_error
NULL

#' Wrap a Function to Add Telemetry Logging
#'
#' A higher-order function that takes a target function and returns a new
#' version of that function. When the new function is called, it executes the
#' original function and logs a structured telemetry event describing the call's
#' context and outcome.
#'
#' The logged event includes a timestamp, status (success/error), duration,
#' and optional arguments and return values. All log messages are directed to
#' the private `impact.telemetry` namespace and will only be recorded if
#' `start_telemetry_logging()` has been called.
#'
#' @param f The function to wrap with telemetry logging.
#' @param event_name A character string providing a human-readable name for the
#'   event being logged. If `NULL` (the default), the name of the function `f`
#'   is used.
#' @param log_args A boolean flag. If `TRUE`, the function's arguments are
#'   captured in the log entry.
#' @param log_result A boolean flag. If `TRUE`, the function's return value is
#'   captured in the log entry.
#' @return A new function that is a version of `f` with telemetry enabled.
#' @export
#' @examples
#' start_telemetry_logging() # Initialize logging before using this function
#'
#' # Define a function
#' calculate_sum <- function(a, b) a + b
#'
#' # Create an instrumented version
#' logged_sum <- with_telemetry(calculate_sum, event_name = "sum_calculation")
#'
#' # Calling this function will now generate a log entry
#' result <- logged_sum(10, 20)
with_telemetry <- function(f,
                           event_name = NULL,
                           log_args = TRUE,
                           log_result = FALSE) {
  event <- event_name %||% deparse(substitute(f))

  function(...) {
    if (!isTRUE(.pkg_env$is_initialized)) {
      cli::cli_warn(
        paste0(
          c(
            "impact.telemetry has not been initialized. Call ",
            "start_telemetry_logging() to enable logging."
          )
        )
      )
      return(f(...))
    }

    # A list to hold optional fields for the JSON log.
    log_fields <- list()

    if (log_args) {
      log_fields$args <- list(...)
    }

    start_time <- Sys.time()

    tryCatch(
      {
        res <- f(...) # Call the original function

        duration <- as.numeric(
          difftime(Sys.time(), start_time, units = "secs")
        ) * 1000

        log_fields$duration_ms <- round(duration, 3)

        if (log_result) {
          log_fields$result <- res
        }

        do.call(
          logger::log_info,
          c(
            list(
              "{event}: success",
              event = event,
              status = "success",
              namespace = .telemetry_ns
            ),
            log_fields
          )
        )

        return(res)
      },
      error = function(e) {
        duration <- as.numeric(
          difftime(Sys.time(), start_time, units = "secs")
        ) * 1000

        log_fields$error_message <- e$message
        log_fields$duration_ms <- round(duration, 3)

        do.call(
          logger::log_error,
          c(
            list(
              "{event}: error",
              event = event,
              status = "error",
              namespace = .telemetry_ns
            ),
            log_fields
          )
        )

        cli::cli_abort(e)
      }
    )
  }
}
